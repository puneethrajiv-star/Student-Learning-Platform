import type { CSSProperties } from "react";
import { courseModules, flatLessons } from "./courseContent";
import type { Navigate } from "./types";
import { Icon } from "./ui";

export default function CourseSidebar({
  navigate,
  selectedIndex,
  completedThrough,
  onSelect,
}: {
  navigate: Navigate;
  selectedIndex: number;
  completedThrough: number;
  onSelect: (index: number) => void;
}) {
  let lessonIndex = -1;
  const progress = Math.round(((completedThrough + 1) / flatLessons.length) * 100);

  return (
    <aside className="lesson-sidebar">
      <button className="back-link" onClick={() => navigate("home")}><Icon name="arrow" size={17} /> Back to EduBridge</button>
      <div className="course-side-heading">
        <span className="course-symbol">C</span>
        <div><small>Course</small><strong>C Programming</strong></div>
      </div>
      <div className="course-progress">
        <span><b>Overall progress</b><small>{progress}%</small></span>
        <i><b style={{ width: `${progress}%` }} /></i>
      </div>
      <nav className="syllabus-list" aria-label="C Programming syllabus">
        {courseModules.map((module, moduleIndex) => (
          <section className="syllabus-module" key={module.title}>
            <p>Module {moduleIndex + 1} <span>—</span> {module.title}</p>
            <div className="lesson-list">
              {module.lessons.map((item, moduleLessonIndex) => {
                lessonIndex += 1;
                const index = lessonIndex;
                const current = index === selectedIndex;
                const complete = index <= completedThrough && !current;
                const locked = index > Math.max(completedThrough + 1, selectedIndex);
                const state = current ? "current" : complete ? "complete" : locked ? "locked" : "available";
                return (
                  <button
                    className={`${state} stagger-item`}
                    style={{ "--item-index": moduleLessonIndex } as CSSProperties}
                    key={item.id}
                    disabled={locked}
                    onClick={() => onSelect(index)}
                  >
                    <span className="lesson-state">
                      {complete ? <Icon name="check" size={14} /> : locked ? <Icon name="lock" size={13} /> : index + 1}
                    </span>
                    <span><strong>{item.title}</strong></span>
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </nav>
    </aside>
  );
}
