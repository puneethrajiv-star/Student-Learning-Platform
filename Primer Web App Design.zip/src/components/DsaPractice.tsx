import { useState, type CSSProperties } from "react";
import { Icon, PageHeader } from "./ui";

const problems = [
  { title: "Find the largest element", topic: "Arrays", difficulty: "Easy", time: "10 min", solved: true },
  { title: "Reverse a string", topic: "Strings", difficulty: "Easy", time: "15 min", solved: false },
  { title: "Valid parentheses", topic: "Stacks", difficulty: "Medium", time: "25 min", solved: false },
  { title: "Two sum", topic: "Hash maps", difficulty: "Medium", time: "30 min", solved: false },
  { title: "Merge sorted lists", topic: "Linked lists", difficulty: "Hard", time: "40 min", solved: false },
];

export default function DsaPractice() {
  const [filter, setFilter] = useState("All");
  const visible = filter === "All" ? problems : problems.filter((problem) => problem.difficulty === filter);
  return (
    <div className="content">
      <PageHeader eyebrow="Build your problem-solving muscle" title="DSA practice" copy="One thoughtful problem a day is enough to make real progress." />
      <div className="dsa-summary"><span><Icon name="flame" /><b>6 day streak</b></span><span><Icon name="check" /><b>12 solved</b></span></div>
      <div className="filter-row">
        {["All", "Easy", "Medium", "Hard"].map((item) => <button className={filter === item ? "selected" : ""} onClick={() => setFilter(item)} key={item}>{item}</button>)}
      </div>
      <section className="problem-list">
        {visible.map((problem, index) => (
          <button className="problem-row stagger-item" style={{ "--item-index": index } as CSSProperties} key={problem.title}>
            <span className={`status-circle ${problem.solved ? "solved" : ""}`}>{problem.solved && <Icon name="check" size={15} />}</span>
            <span><strong>{problem.title}</strong><small>{problem.topic} · {problem.time}</small></span>
            <em className={`difficulty ${problem.difficulty.toLowerCase()}`}>{problem.difficulty}</em>
            <Icon name="chevron" size={18} />
          </button>
        ))}
      </section>
    </div>
  );
}
