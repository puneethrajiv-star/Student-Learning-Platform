import { useState } from "react";
import { Brand, Icon } from "./ui";

const noExperienceQuestions = [
  {
    title: "Which language would you like to begin with?",
    note: "There is no wrong choice. We’ll shape your first course around it.",
    options: ["Python — friendly and versatile", "C — strong foundations", "Java — structured and widely used"],
  },
  {
    title: "How do you feel about the terminal?",
    note: "The terminal is a text-based way to give your computer instructions.",
    options: ["I’ve never used it", "I’ve tried a few commands", "I can navigate comfortably"],
  },
  {
    title: "How comfortable are you finding files on your computer?",
    note: "Think folders, downloads, installing apps, and changing basic settings.",
    options: ["I’d like help with the basics", "I can usually find my way", "I’m very comfortable"],
  },
];

const experienceQuestions = [
  {
    title: "How familiar are you with roles in technology?",
    note: "Knowing what people do day-to-day can make choosing a path easier.",
    options: ["Not yet — show me the possibilities", "I know a few roles", "I have a clear picture"],
  },
  {
    title: "Which direction sounds most interesting?",
    note: "You can explore another path at any time.",
    options: ["Build websites and apps", "Work with data and insights", "Explore AI and machine learning", "I’m still deciding"],
  },
];

export default function Onboarding({ onFinish }: { onFinish: (experienced: boolean) => void }) {
  const [answers, setAnswers] = useState<string[]>([]);
  const [experience, setExperience] = useState<"none" | "some" | "comfortable" | null>(null);
  const questions = experience === "none" ? noExperienceQuestions : experience ? experienceQuestions : [];
  const step = answers.length;
  const current = step === 0
    ? { title: "How much programming have you tried before?", note: "This helps us start at the right place. Be honest — beginners belong here.", options: ["None at all", "I’ve tried some basics", "I’m comfortable programming"] }
    : questions[step - 1];
  const total = experience === "none" ? 4 : experience ? 3 : 4;

  function choose(option: string) {
    if (step === 0) {
      const level = option.startsWith("None") ? "none" : option.startsWith("I’ve tried") ? "some" : "comfortable";
      setExperience(level);
      setAnswers([option]);
      return;
    }
    const next = [...answers, option];
    if (next.length === total) onFinish(experience !== "none");
    else setAnswers(next);
  }

  return (
    <main className="onboarding-page">
      <Brand />
      <section className="question-wrap">
        <div className="progress-meta">
          <span>Getting to know you</span>
          <span>Question {step + 1} of {total}</span>
        </div>
        <div className="progress-track"><span style={{ width: `${((step + 1) / total) * 100}%` }} /></div>
        <div className="question-card">
          <p className="eyebrow">A quick check-in</p>
          <h1>{current.title}</h1>
          <p className="question-note">{current.note}</p>
          <div className="option-list">
            {current.options.map((option) => (
              <button key={option} onClick={() => choose(option)}>
                <span>{option}</span><Icon name="chevron" size={18} />
              </button>
            ))}
          </div>
        </div>
        <p className="reassurance"><Icon name="spark" size={16} /> Your answers only personalize your learning plan.</p>
      </section>
    </main>
  );
}
