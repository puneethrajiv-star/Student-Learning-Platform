import { useState } from "react";
import { flatLessons } from "./courseContent";
import CourseSidebar from "./CourseSidebar";
import type { Navigate } from "./types";
import { Button, Icon } from "./ui";

type LessonMode = "Text" | "Video" | "Live coding";

const playlistId = "PLZPZq0r_RZOOzY_vR4zJM32SqsSInGMwe";

export default function CourseDetail({ navigate }: { navigate: Navigate }) {
  const [selectedIndex, setSelectedIndex] = useState(1);
  const [completedThrough, setCompletedThrough] = useState(0);
  const [mode, setMode] = useState<LessonMode>("Text");
  const selected = flatLessons[selectedIndex];
  const progress = Math.round(((completedThrough + 1) / flatLessons.length) * 100);

  function nextLesson() {
    if (selectedIndex >= flatLessons.length - 1) return;
    setCompletedThrough((current) => Math.max(current, selectedIndex));
    setSelectedIndex((current) => current + 1);
  }

  return (
    <div className="course-shell">
      <CourseSidebar
        navigate={navigate}
        selectedIndex={selectedIndex}
        completedThrough={completedThrough}
        onSelect={setSelectedIndex}
      />
      <main className="lesson-main">
        <div className="lesson-content">
          <div className="lesson-progress">
            <span>Lesson {selectedIndex + 1} of {flatLessons.length}</span>
            <i><b style={{ width: `${progress}%` }} /></i>
            <span>{progress}% complete</span>
          </div>

          <div className="lesson-mode-tabs" role="tablist" aria-label="Lesson content mode">
            {(["Text", "Video", "Live coding"] as LessonMode[]).map((item) => (
              <button role="tab" aria-selected={mode === item} className={mode === item ? "selected" : ""} onClick={() => setMode(item)} key={item}>
                {item === "Text" && <Icon name="book" size={16} />}
                {item === "Video" && <Icon name="layers" size={16} />}
                {item === "Live coding" && <Icon name="code" size={16} />}
                {item}
              </button>
            ))}
          </div>

          <p className="eyebrow">{selected.module}</p>
          <h1>{selected.title}</h1>

          {mode === "Text" && (
            <div className="lesson-mode-panel">
              <p className="lesson-intro">{selected.explanation}</p>
              <section className="concept-section">
                <h2>Important concepts</h2>
                <ul>
                  {selected.concepts.map((concept) => <li key={concept}><Icon name="check" size={15} /> {concept}</li>)}
                </ul>
              </section>

              {selected.code && (
                <section className="lesson-copy">
                  <div className="code-heading"><h2>Code example</h2><span>C</span></div>
                  <pre className="code-block"><code>{selected.code}</code></pre>
                </section>
              )}

              <section className="lesson-note">
                <span><Icon name="spark" size={19} /></span>
                <div><strong>Keep in mind</strong><p>Read the code from top to bottom and identify the type, variable name, and value before running it.</p></div>
              </section>
            </div>
          )}

          {mode === "Video" && (
            <section className="video-lesson lesson-mode-panel">
              <div><h2>Watch this lesson</h2><p>Follow the C Programming course playlist, then return to the live editor to practise the idea yourself.</p></div>
              <div className="video-frame">
                <iframe
                  src={`https://www.youtube.com/embed/videoseries?list=${playlistId}`}
                  title={`C Programming playlist — ${selected.title}`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <a href={`https://www.youtube.com/playlist?list=${playlistId}`} target="_blank" rel="noreferrer">Open the full playlist on YouTube <Icon name="arrow" size={15} /></a>
            </section>
          )}

          {mode === "Live coding" && (
            <section className="live-coding lesson-mode-panel">
              <div className="coding-heading">
                <div><h2>Practice in C</h2><p>Type, compile, and run C while following the lesson.</p></div>
              </div>
              <div className="compiler-frame">
                <iframe
                  src="https://onecompiler.com/embed/c?hideLanguageSelection=true&hideNew=true&theme=dark"
                  title={`C live coding editor — ${selected.title}`}
                  allow="clipboard-read; clipboard-write"
                />
              </div>
              <p className="runner-note">The editor runs through OneCompiler in an isolated environment. Do not enter personal information.</p>
            </section>
          )}

          <div className="lesson-actions">
            <Button variant="secondary" onClick={() => setSelectedIndex((current) => Math.max(0, current - 1))} disabled={selectedIndex === 0}>Previous</Button>
            <Button onClick={nextLesson} disabled={selectedIndex === flatLessons.length - 1}>Next lesson <Icon name="arrow" size={18} /></Button>
          </div>
        </div>
      </main>
    </div>
  );
}
