import type { CSSProperties } from "react";
import { courses } from "./courseData";
import type { Navigate } from "./types";
import { Button, Icon, PageHeader } from "./ui";

export default function Home({ navigate }: { navigate: Navigate }) {
  return (
    <div className="content home-content">
      <PageHeader eyebrow="Your learning space" title="Good afternoon, Arjun" copy="A few small steps today will take you a long way." />
      <div className="home-grid">
        <section className="streak-card">
          <div className="streak-icon"><Icon name="flame" size={24} /></div>
          <p>DSA streak</p><strong>6 days</strong>
          <span>Your longest yet</span>
          <div className="week-row">
            {["M", "T", "W", "T", "F", "S", "S"].map((day, index) => <i className={index < 6 ? "done" : ""} key={`${day}-${index}`}>{index < 6 ? <Icon name="check" size={13} /> : day}</i>)}
          </div>
          <Button variant="secondary" onClick={() => navigate("dsa")}>Practice today</Button>
        </section>
        <div className="home-primary">
          <button className="typing-card" onClick={() => navigate("typing")}>
            <span className="feature-icon"><Icon name="keyboard" size={26} /></span>
            <span><small>Daily practice</small><strong>Warm up your typing</strong><em>10 minutes · Continue your current drill</em></span>
            <Icon name="arrow" />
          </button>
          <section className="joined-section">
            <div className="section-heading"><div><p className="eyebrow">Your courses</p><h2>Continue learning</h2></div><button onClick={() => navigate("browse")}>Browse all</button></div>
            {courses.map((course, index) => (
              <button className="course-row stagger-item" style={{ "--item-index": index } as CSSProperties} key={course.title} onClick={() => navigate("course")}>
                <span className="course-symbol">{course.icon}</span>
                <span className="course-info"><strong>{course.title}</strong><small>{course.category} · {course.length}</small><i><b style={{ width: `${course.progress}%` }} /></i></span>
                <span className="progress-number">{course.progress}%</span><Icon name="chevron" size={18} />
              </button>
            ))}
          </section>
        </div>
      </div>
    </div>
  );
}
