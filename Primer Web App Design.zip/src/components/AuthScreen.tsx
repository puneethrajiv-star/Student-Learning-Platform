import type { Navigate } from "./types";
import { Brand, Button, Field, Icon } from "./ui";

export default function AuthScreen({ mode, navigate }: { mode: "signup" | "login"; navigate: Navigate }) {
  const signup = mode === "signup";
  return (
    <main className="auth-page">
      <button className="brand-button" onClick={() => navigate("landing")} aria-label="Back to EduBridge home"><Brand /></button>
      <section className="auth-card">
        <p className="eyebrow">{signup ? "Start your journey" : "Welcome back"}</p>
        <h1>{signup ? "Create your account" : "Continue learning"}</h1>
        <p className="muted">{signup ? "A calmer way to prepare for computer science." : "Pick up right where you left off."}</p>
        <form onSubmit={(event) => { event.preventDefault(); navigate(signup ? "onboarding" : "home"); }}>
          {signup && <Field label="Your name" placeholder="What should we call you?" />}
          <Field label="Email address" type="email" placeholder="you@example.com" />
          <Field label="Password" type="password" placeholder="At least 8 characters" />
          <Button type="submit" className="full-button">{signup ? "Create account" : "Log in"} <Icon name="arrow" size={18} /></Button>
        </form>
        <p className="auth-switch">
          {signup ? "Already have an account?" : "New to EduBridge?"}{" "}
          <button onClick={() => navigate(signup ? "login" : "signup")}>{signup ? "Log in" : "Sign up"}</button>
        </p>
      </section>
    </main>
  );
}
