import type { CSSProperties } from "react";
import { courses } from "./courseData";
import type { Navigate } from "./types";
import { Button, Icon, PageHeader } from "./ui";

export default function BrowseCourses({ navigate }: { navigate: Navigate }) {
  return (
    <div className="content">
      <PageHeader eyebrow="Course library" title="Find your next course" copy="Begin with the foundations, then follow your curiosity." />
      <div className="filter-row"><button className="selected">All courses</button><button>Programming</button></div>
      <div className="course-grid single-course">
        {courses.map((course, index) => (
          <article className="course-card stagger-item" style={{ "--item-index": index } as CSSProperties} key={course.title}>
            <span className={`course-art art-${index % 3}`}><b>{course.icon}</b></span>
            <div className="course-card-body">
              <span className="course-category">{course.category}</span>
              <h2>{course.title}</h2>
              <p>{course.length} · {course.level}</p>
              <Button variant={course.progress ? "secondary" : "primary"} onClick={() => navigate("course")}>{course.progress ? "Continue course" : "View course"} <Icon name="arrow" size={17} /></Button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
